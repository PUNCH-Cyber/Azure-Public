import requests
import logging
import gzip
import time
from . import generalFunctions
from . import logAnalytics

################################################################################################
# MONGODB ATLAS FUNCTIONS
################################################################################################

# MongoDB Atlas API Requests
def mongodb_atlas_api (logType, startTime, groupId = "", orgId = "", clusterName = ""):

    # Define request filters and headers
    filters = "includeCount=true&itemsPerPage=500&envelope=true"
    timeRange = "minDate={}&maxDate={}".format(startTime, end_time)
    epochStartTime = generalFunctions.convert_to_epoch(startTime, dateFormat)
    epochEndTime = generalFunctions.convert_to_epoch(end_time, dateFormat)
    headers = {"Content-Type": "application/json"}

    # Define uri based on log type
    if logType == "OrgEvents":
        uri = "{}/orgs/{}/events?{}&{}".format(baseUrl, orgId, filters, timeRange)
    elif logType == "ProjEvents":
        uri = "{}/groups/{}/events?{}&{}".format(baseUrl, groupId, filters, timeRange)
    elif logType == "Clusters":
        uri = "{}/groups/{}/clusters?includeCount=true&envelope=true".format(baseUrl, groupId)
    elif logType == "ClusterAccessLogs":
        uri = "{}/groups/{}/dbAccessHistory/clusters/{}?envelope=true&nLogs=2000&start={}&end={}".format(baseUrl, groupId, clusterName, epochStartTime, epochEndTime)
    else:
       logging.error('LogType parameter not valid. Acceptable values: OrgEvents, ProjEvents, ClusterAccessLogs')
       
    # API Request/Response processing with Pagination
    responseCollection = []
    while uri:
        logging.info("[{}]: Invoking URI: {}".format(logType, uri))
        response = (requests.get(uri, headers=headers, auth=auth)).json()
        
        if groupId:
            generalFunctions.api_rate_limit_tracking(groupId, apiRequestCounter)
    
        if response.get('accessLogs'):
            for i in response.get('accessLogs'):
                responseCollection.append(i)
            logging.info("[{}]: {} record(s) added to the collection".format(logType,len(response['accessLogs'])))
            generalFunctions.update_checkpoint_entry(logType, azureBlobStorageUrl, checkpointTable, orgId=orgId, groupId=groupId, clusterName=clusterName, atlasRespStatus = "Success")
            uri = None
        elif response.get('status') == 200:
            for i in response.get('content').get('results'):
                responseCollection.append(i)
            logging.info("[{}]: {} record(s) added to the collection, {}/{} Total".format(logType,len(response['content']['results']),len(responseCollection), response['content']['totalCount']))
            next_uri = next((i for i in response['content']['links'] if i["rel"] == "next"), None)
            uri = next_uri
            generalFunctions.update_checkpoint_entry(logType, azureBlobStorageUrl, checkpointTable, orgId=orgId, groupId=groupId, clusterName=clusterName, atlasRespStatus = "Success")
        elif response.get('error'):
            logging.error("[{}]: Unexpected API Response - {};{}".format(logType,response['error'], response['details']))
            generalFunctions.update_checkpoint_entry(logType, azureBlobStorageUrl, checkpointTable, orgId=orgId, groupId=groupId, clusterName=clusterName, atlasRespStatus = "Failed")
            uri = None
        else:
            uri = None
    
    logging.info("[{}]: {} Total Record(s) Found (Time Range: {} - {})".format(logType, len(responseCollection), startTime, end_time))
    return responseCollection

# Download and Decompress Host Audit Logs
def download_audit_logs(logType, groupId, clusterName, hostname, startTime, filename):
    """
    Requests audit logs for a single host

    Downloads the logs for a particular host and sends them to Splunk

    :param atlas_project_id:    A String representing the project id of the Atlas project whose logs we are downloading
    :param host_name:           A String representing the host name whose logs we are downloading
    :return:                    Decompressed bytes object representation of the logs from server
    """
    
    # Define request filters
    epochStartTime = generalFunctions.convert_to_epoch(startTime, dateFormat)
    epochEndTime = generalFunctions.convert_to_epoch(end_time, dateFormat)
    headers = {"accept": "application/gzip"}
    # Download audit log file
    uri = "{}/groups/{}/clusters/{}/logs/{}.gz?startDate={}&endDate={}".format(baseUrl, groupId, hostname, filename, epochStartTime, epochEndTime)
    logging.info("[{}]: Invoking URI: {}".format(logType, uri))
    response = requests.get(uri, auth=auth, headers=headers)
    
    generalFunctions.api_rate_limit_tracking(groupId, apiRequestCounter)

    if response.status_code != 200:
        response = response.json()
        logging.info("[{}]: hostname={};filename={});msg=Audit File download failed;error: {}:{}".format(logType, hostname, filename, startTime, end_time, response['error'], response['detail'], response['reason']))
        generalFunctions.update_checkpoint_entry(logType, azureBlobStorageUrl, checkpointTable, groupId=groupId, hostname=hostname, clusterName=clusterName, filename=filename, atlasRespStatus = "Failed")
        auditLogs = []
    else:
        logging.info("[{}]: hostname={};filename={});msg=Audit File downloaded successfully (Time Range: {} - {})".format(logType, hostname, filename, startTime, end_time))
        generalFunctions.update_checkpoint_entry(logType, azureBlobStorageUrl, checkpointTable, groupId=groupId, hostname=hostname, clusterName=clusterName, filename=filename, atlasRespStatus = "Success")
        decompressed = gzip.decompress(response.content)
        auditLogs = generalFunctions.convert_to_json(decompressed)
    
    return auditLogs

# Function to process, transform and normalize Org Events, Project Events, and Cluster Access Logs
def process_atlas_events(events, logType):
    
    if events:
        eventCollection = []
        for event in events:
            event['logCategory'] = logType
            
            eventCollection.append(event)
            
        return eventCollection
    else:
        return None

# Function to process, transform and normalize Audit Logs
def process_audit_logs(events, clusterName, hostname, groupId, filename, logType):
    
    if events:
        eventCollection = []
        for event in events:
            event['logCategory'] = logType
            event['groupId'] = groupId
            event['hostname'] = hostname
            event['clusterName'] = clusterName
            event['filename'] = filename
            
            eventCollection.append(event)
            
        return eventCollection
    else:
        return None

# Pasrse out the hostnames required to download the Host Audit Logs
def parse_host_from_uri(mongoURI):
    """
    Parse host names from URI

    :param mongoURI:    A String representing the mongodb connection uri
    :return:            An array of Strings, each of which is a host in the mongodb cluster represented by the URI
    """
    hosts = []
    split_conn_str = mongoURI.split("//")
    split_conn_str = split_conn_str[1].split(",")
    for host_port in split_conn_str:
        split_host = host_port.split(":")
        hosts.append(split_host[0])
    hosts = list(set(hosts))
    return hosts
            
################################################################################################
# LOG PROCESSING FUNCTIONS
################################################################################################

# Retrieves org events logs from MongoDB Atlas, processes and post to Log Analytics
def etl_org_events(orgs):
    
    logType = "OrgEvents"
    for i in range(len(orgs)):
        orgIds.append(orgs[i]['id'])
        
    logging.info("[Orgs]: {} Org(s) Found".format(len(orgIds)))

    for org in orgIds:
        
        # Determine Time Interval for API request
        start_time = generalFunctions.get_start_time(logType, end_time, dateFormat, timeInterval, azureBlobStorageUrl, checkpointTable, org)
         
        # Retrieve all Org Events
        allOrgEvents = mongodb_atlas_api(logType=logType, orgId=org, startTime=start_time)

        # Process, transform, and normalize Org Events
        orgEvents = process_atlas_events(allOrgEvents, logType)
        
        # Pre-post processing and validation then post to Log Analytics workspace
        logAnalytics.dataprocessing(orgEvents, azureBlobStorageUrl, checkpointTable, end_time, logType, workspaceId, workspaceKey, tableName, org)

# Retrieves proj events logs from MongoDB Atlas, processes and post to Log Analytics
def etl_proj_events(allProjs):
    
    logType = "ProjEvents"
    
    for proj in allProjs['content']['results']:
        
        # Retrieve checkpoint time
        start_time = generalFunctions.get_start_time(logType, end_time, dateFormat, timeInterval, azureBlobStorageUrl, checkpointTable, proj['orgId'], proj['id'])
        
        # Add record to track API request per project
        newCounterObj = {
            'groupId': proj['id'],
            'projectName': proj['name'],
            'requestTimes': [],
            'apiRequestsInLastMin': 0
        }
        apiRequestCounter.append(newCounterObj)
        
        # Identify all Clusters within the project
        response = (requests.get("{}/groups/{}/clusters?includeCount=true&envelope=true".format(baseUrl, proj['id']), auth=auth)).json()
        clusters = response['content']['results']
        
        logging.info("[{}]: {} Cluster(s) found in project={};projectName={}".format(logType, len(clusters), proj['id'], proj['name']))
        for i in range(len(clusters)):
            allClusters.append(clusters[i])
            
        # Request all Project Events
        logging.info("[{}]: Processing Project Events for orgId={};project={};projectName={}".format(logType, proj['orgId'], proj['id'], proj['name']))
        allProjEvents = mongodb_atlas_api(logType, start_time, proj['id'], orgId=proj['orgId'])

        # Process, transform, and normalize Project Events
        projEvents = process_atlas_events(allProjEvents, logType)
        
        # Pre-post processing and validation then post to Log Analytics workspace
        logAnalytics.dataprocessing(projEvents, azureBlobStorageUrl, checkpointTable, end_time, logType, workspaceId, workspaceKey, tableName, proj['orgId'], proj["id"])

# Retrieves cluster access logs from MongoDB Atlas, processes and post to Log Analytics
def etl_cluster_access_logs(clusterList):
    
    logType = "ClusterAccessLogs"
    for cluster in clusterList:
    
        # Retrieve checkpoint time
        start_time = generalFunctions.get_start_time(logType, end_time, dateFormat, timeInterval, azureBlobStorageUrl, checkpointTable, groupId=cluster['groupId'], clusterName=cluster['name'])
        
        # Request all Cluster Access Logs
        logging.info("[{}]: Processing Cluster Access Logs for {}".format(logType,cluster['name']))
        allClusterAccessLogs = mongodb_atlas_api(logType, start_time, cluster['groupId'], clusterName=cluster['name'])
        
        # Process, transform, and normalize all Cluster Access Logs
        clusterAccessLogs = process_atlas_events(allClusterAccessLogs, logType)

        # Pre-post processing and validation then post to Log Analytics workspace
        logAnalytics.dataprocessing(clusterAccessLogs, azureBlobStorageUrl, checkpointTable, end_time, logType, workspaceId, workspaceKey, tableName, groupId=cluster['groupId'], clusterName=cluster['name'])
        
        # Parse all hostnames from each cluster, utilized to retrieve audit logs
        hostUris = parse_host_from_uri(cluster['mongoURI'])
        for host in hostUris:
            obj = {
                'hostname': host,
                'groupId': cluster['groupId'],
                'clusterName': cluster['name']
            }
            clusterHostnames.append(obj)
  
# Downloads host audit logs from MongoDB Atlas, processes and post to Log Analytics            
def etl_audit_logs(clusterHostnames):
    
    logType = "AuditLogs"
    # Define audit log types
    auditLogTypes = ['mongodb-audit-log', 'mongodb']
    
    for hostname in clusterHostnames:
    
        # Download and decompress each audit file for the current host in the cluster and post to Log Analuytics
        for filename in auditLogTypes:
            
            # Retrieve checkpoint time
            start_time = generalFunctions.get_start_time(logType, end_time, dateFormat, timeInterval, azureBlobStorageUrl, checkpointTable, groupId=hostname['groupId'], clusterName=hostname['clusterName'], hostname=hostname['hostname'], filename=filename)
            
            # Download Audit File from Atlas API
            allAuditLogs = download_audit_logs(logType, hostname['groupId'], hostname['clusterName'], hostname['hostname'], start_time, filename)
            logging.info("[{}]: hostname={};filename={};msg={} Audit events found".format(logType, hostname['hostname'], filename, len(allAuditLogs)))
            
            # Process, transform, and normalize Audit Logs
            auditLogs = process_audit_logs(allAuditLogs, hostname['clusterName'], hostname['hostname'], hostname['groupId'], filename, logType)

            # # Pre-post processing and validation then post to Log Analytics workspace   
            logAnalytics.dataprocessing(auditLogs, azureBlobStorageUrl, checkpointTable, end_time, logType, workspaceId, workspaceKey, tableName, groupId=hostname['groupId'], clusterName=hostname['clusterName'], hostname=hostname['hostname'], filename=filename)

################################################################################################
# MAIN SCRIPT
################################################################################################

# Start Processing Marker
def main_script(base_url, api_auth, run_time, workspace_id, workspace_key, table_name, time_interval, sa_conn_string, checkpoint_table, date_format):
            
    # Start Processing Marker
    start_stop_watch = time.time()
    
    global baseUrl, auth, end_time, workspaceId, workspaceKey, tableName, timeInterval, azureBlobStorageUrl, dateFormat, checkpointTable
    baseUrl = base_url
    auth = api_auth 
    end_time = run_time    
    workspaceId = workspace_id    
    workspaceKey = workspace_key    
    tableName = table_name
    timeInterval = time_interval
    azureBlobStorageUrl = sa_conn_string    
    checkpointTable = checkpoint_table  
    dateFormat = date_format      
        
    global orgIds, allClusters, clusterHostnames, apiRequestCounter
    orgIds = []
    allClusters = []
    clusterHostnames = []
    apiRequestCounter = []

    retryThreshold = 2
    # Identify all Org Ids and Org Events
    retry = 0 
    while retry != retryThreshold:
        allOrgs = (requests.get(url="{}/orgs?includeCount=true&envelope=true".format(baseUrl), auth=auth)).json()
        if allOrgs.get('status') == 200:
            orgs = allOrgs.get('content').get('results')
            # Retrieve all Org Events and post to Log Analytics
            etl_org_events(orgs)
            retry = retryThreshold
        else:
            orgRespError = allOrgs.get('error')
            logging.info("[Orgs]: Unexpected API Error. Retrying...")
            retry += 1

    # Identify all Projects and Project Events
    retry = 0 
    while retry != retryThreshold:
        retry = 0 
        allProjs = (requests.get("{}/groups?includeCount=true&envelope=true".format(baseUrl), auth=auth)).json()
        if allProjs.get('status') == 200:
            logging.info("[Projs]: {} Project(s) Found".format(len(allProjs['content']['results'])))
            # Process all Project Events
            etl_proj_events(allProjs)
            retry = retryThreshold
        else:
            projRespError = allProjs.get('error')
            logging.info("[Projs]: Unexpected API Error. Retrying...")
            retry += 1
            
    # Process all Cluster Access Logs
    etl_cluster_access_logs(allClusters)

    # Process all Audit Logs
    etl_audit_logs(clusterHostnames)   
           
    # End Processing Marker
    end_stop_watch = time.time()
    time_lapsed = end_stop_watch - start_stop_watch
    logging.info("Total execution time: {} seconds".format(time_lapsed))
    
    
################################################################################################
# END SCRIPT
################################################################################################
