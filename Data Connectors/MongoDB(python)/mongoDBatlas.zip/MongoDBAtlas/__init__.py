import logging
import os

from datetime import datetime
from requests.auth import HTTPDigestAuth
import azure.functions as func
from . import mongoDBAtlas

def main(mytimer: func.TimerRequest) -> None:
    
    configure_logger()
    logging.info(logging.getLogger().getEffectiveLevel())
    
    # MangoDB Atlas API Variables
    publicKey = os.environ["publicKey"]
    privateKey = os.environ["privateKey"]
    timeInterval = int(os.environ["timeInterval"]) # the last 'x' minutes (e.g. 5 = the last 5 mins)
    baseUrl = "https://cloud.mongodb.com/api/atlas/v1.0"
    auth = HTTPDigestAuth(publicKey, privateKey)
    dateFormat = '%Y-%m-%dT%H:%M:%S'
    end_time = datetime.strftime(datetime.utcnow(), dateFormat)
    
    # Log Analytics Variables
    workspaceId = os.environ["workspaceId"]
    workspaceKey = os.environ["workspaceKey"]
    tableName = "MongoDB"

    # General Variables
    checkpointTable = "AtlasAPICheckpoints"
    azureBlobStorageUrl =  os.environ["AzureWebJobsStorage"] 

    mongoDBAtlas.main_script(base_url=baseUrl,
                             api_auth=auth, 
                             run_time=end_time, 
                             workspace_id=workspaceId, 
                             workspace_key=workspaceKey, 
                             table_name=tableName,
                             time_interval=timeInterval,
                             sa_conn_string=azureBlobStorageUrl,
                             checkpoint_table=checkpointTable,
                             date_format=dateFormat)
    
    if mytimer.past_due:
        logging.info('The timer is past due!')
        
    logging.info('Python timer trigger function ran at %s')
    
def configure_logger():
    """
    Generates basic logger at either debug or info level
    """
    if "debug" in os.environ and os.environ["debug"] == True:
        log_level = "debug"
    else:
        log_level = "info"

    format = "%(levelname)s: %(message)s"
    logging.basicConfig(format=format, level=log_level.upper())