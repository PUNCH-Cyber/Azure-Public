from re import I, L
import requests
import json
import logging
import hashlib
import hmac
import base64

from datetime import datetime
from . import generalFunctions

################################################################################################
# LOG ANALYTICS FUNCTIONS
################################################################################################        

# Build the API signature
def build_signature (customer_id, shared_key, date, content_length, method, content_type, resource):
    x_headers = 'x-ms-date:' + date
    string_to_hash = method + "\n" + str(content_length) + "\n" + content_type + "\n" + x_headers + "\n" + resource
    bytes_to_hash = bytes(string_to_hash, encoding="utf-8")  
    decoded_key = base64.b64decode(shared_key)
    encoded_hash = base64.b64encode(hmac.new(decoded_key, bytes_to_hash, digestmod=hashlib.sha256).digest()).decode()
    authorization = "SharedKey {}:{}".format(customer_id,encoded_hash)
    return authorization

# Build and send a request to the POST API
def post_data (customer_id, shared_key, body, log_type):
    method = 'POST'
    content_type = 'application/json'
    resource = '/api/logs'
    rfc1123date = datetime.utcnow().strftime('%a, %d %b %Y %H:%M:%S GMT')
    content_length = len(body)
    signature = build_signature(customer_id, shared_key, rfc1123date, content_length, method, content_type, resource)
    uri = 'https://' + customer_id + '.ods.opinsights.azure.com' + resource + '?api-version=2016-04-01'

    headers = {
        'content-type': content_type,
        'Authorization': signature,
        'Log-Type': log_type,
        'x-ms-date': rfc1123date
    }

    response = requests.post(uri,data=body, headers=headers)
    return response

# Process payload into JSON format, assess the payload size and POST to log analytics workspace
def dataprocessing(payload, azureBlobStorageUrl, checkpointTable, lastSuccessTime, logType, workspaceId, workspaceKey, tableName, orgId = "", groupId = "", clusterName = "", hostname = "", filename = ""):
    
    if payload:
        # Convert payload to JSON
        body = json.dumps(payload)
        payloadSize = round(generalFunctions.calculate_obj_size(body, "m"), 3)
        
        if payloadSize < 30:
            logging.info("[{}]: Posting {} record(s) to Log Analytics workspace: {} MB".format(logType,len(payload), payloadSize))
            response = post_data(workspaceId, workspaceKey, body, tableName)
            
            if response.status_code == 200:
                logging.info("[{}]: SUCCESS: {} records posted to Log Analytics: {} MB".format(logType,len(payload), payloadSize))
                generalFunctions.update_checkpoint_entry(logType, azureBlobStorageUrl, checkpointTable, lastSuccessTime, orgId, groupId, clusterName, hostname, filename, postRespStatus = "Success")
            else:
                logging.error("[{}]: ERROR: Log Analytics POST unsuccessful: error code={}".format(logType,response.status_code))
                generalFunctions.update_checkpoint_entry(logType, azureBlobStorageUrl, checkpointTable, lastSuccessTime, orgId, groupId, clusterName, hostname, filename, postRespStatus = "Failed")
                
        # If the payload exceeds 30MB, split the payload into chunks and post to Log Analytics
        else:
            logging.warning("JSON payload execeeded Log Analytics API maximum of 30MB: Total size, {} MB. Initiating function to breakup payload...".format(payloadSize))
            array = generalFunctions.payload_split(payload, payloadSize, logType)  
                 
            for i in len(array):                
                if array[i]:
                    array_json = json.dump(array[i])
                    newPayloadSize = round(generalFunctions.calculate_obj_size(array_json, "m"), 3)
                    logging.info("[{}]: Posting {} record(s) to Log Analytics workspace: {} MB".format(logType,len(array[i]), newPayloadSize))
                    response = post_data(workspaceId, workspaceKey, array_json, tableName)
                    if (response.status_code >= 200 and response.status_code <= 299):
                        logging.info("[{}]: SUCCESS: {} records posted to Log Analytics: {} MB".format(logType,len(payload), payloadSize))
                        generalFunctions.update_checkpoint_entry(logType, azureBlobStorageUrl, checkpointTable, lastSuccessTime, orgId, groupId, clusterName, hostname, filename, postRespStatus = "Success")
                    else:
                        logging.error("[{}]: ERROR: Log Analytics POST unsuccessful: error code={}".format(logType,response.status_code))
                        generalFunctions.update_checkpoint_entry(logType, azureBlobStorageUrl, checkpointTable, lastSuccessTime, orgId, groupId, clusterName, hostname, filename, postRespStatus = "Failed")
    else:
        logging.info("[{}]: orgId={};groupId={};clusterName={};hostname={};filename={};msg=No records were found, processed or posted to the Log Analytics workspace".format(logType,orgId, groupId, clusterName, hostname,filename))
        generalFunctions.update_checkpoint_entry(logType, azureBlobStorageUrl, checkpointTable, lastSuccessTime, orgId, groupId, clusterName, hostname, filename, postRespStatus = "Success")