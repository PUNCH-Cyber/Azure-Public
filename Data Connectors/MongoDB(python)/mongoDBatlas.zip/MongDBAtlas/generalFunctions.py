from re import I, L
import json
import logging
import hashlib
import time
import math

from datetime import datetime, timedelta
from azure.data.tables import TableServiceClient

################################################################################################
# GENERAL FUNCTIONS
################################################################################################

# Generation of unique row key for checkpoint recordd
def generate_md5_hash(logType, orgId = "", groupId = "", clusterName = "", hostname = "", filename = ""):
    
    concat_str = logType + orgId + groupId + clusterName + hostname + filename
    md5 = hashlib.md5(concat_str.encode())
    return md5.hexdigest()

# Retrieves the start time based on the checkpoint file
def get_start_time (logType, end_time, dateFormat, timeInterval, azureBlobStorageUrl, checkpointTable, orgId = "", groupId = "", clusterName = "", hostname = "", filename = "", atlasRespStatus = "", postRespStatus = ""):

    endTime = datetime.strptime(end_time, dateFormat)
    start_time = endTime - timedelta(minutes=timeInterval)
    firstStartTimeRecord = datetime.strftime(start_time, dateFormat)
    
    table_service = TableServiceClient.from_connection_string(conn_str=azureBlobStorageUrl)
    # Create checkpoint table if it does not exist
    table_service.create_table_if_not_exists(table_name=checkpointTable)
    table_client = table_service.get_table_client(table_name=checkpointTable)
    rowKey = generate_md5_hash(logType, orgId, groupId, clusterName, hostname, filename)
        
    # Check for an existing checkpoint entry
    try:
        existingEntry = table_client.get_entity(partition_key=logType, row_key=rowKey)
    except Exception:
        existingEntry = None
    
    if existingEntry:
        logging.info("[{}]: orgId={};groupId={};clusterName={};hostname={};filename={};msg=Last Successful Time Checkpoint Entry Found".format(logType, orgId, groupId, clusterName, hostname, filename))
        
        if existingEntry.get('lastSuccessTime'):   
            return existingEntry['lastSuccessTime']
        else:
            return firstStartTimeRecord
    
    # if the record is not found, create a new record and use the interval time as the start time
    else:
        newCheckpointEntry = {
            'PartitionKey': logType,
            'RowKey': rowKey,
            'orgId': orgId,
            'groupId': groupId,
            'clusterName': clusterName,
            'lastSuccessTime': "",
            'hostname': hostname,
            'filename': filename,
            'atlasRespStatus': atlasRespStatus,
            'postRespStatus': postRespStatus
        }
        
        table_client.create_entity(entity=newCheckpointEntry)
        logging.info("[{}]: orgId={};groupId={};clusterName={};hostname={};filename={};msg=New Checkpoint Entry Added".format(logType, orgId, groupId, clusterName, hostname, filename))
        return firstStartTimeRecord

# Updates the checkpoint entry based on the log type
def update_checkpoint_entry(logType, azureBlobStorageUrl, checkpointTable, lastSuccessTime = "", orgId = "", groupId = "", clusterName = "", hostname = "", filename = "", atlasRespStatus = "", postRespStatus = ""):
    
    table_service = TableServiceClient.from_connection_string(conn_str=azureBlobStorageUrl)
    table_client = table_service.get_table_client(table_name=checkpointTable)
    rowKey = generate_md5_hash(logType, orgId, groupId, clusterName, hostname, filename)

    existingEntry = table_client.get_entity(partition_key=logType, row_key=rowKey)
    if existingEntry:       
        # Update the status of the Atlast API request
        if atlasRespStatus:
            existingEntry['atlasRespStatus'] = atlasRespStatus        
                
        # Update the Last Successful time if there was a successful Atlas API request and successful post to Log Analytics
        if existingEntry['atlasRespStatus'] == "Success" and postRespStatus == "Success":
            existingEntry['lastSuccessTime'] = lastSuccessTime
            existingEntry['postRespStatus'] = "Success"
        elif existingEntry['atlasRespStatus'] == "Failed" and postRespStatus:
            existingEntry['postRespStatus'] = "Failed"
        elif postRespStatus == "Failed":
            existingEntry['postRespStatus'] = "Failed"
            
        table_client.update_entity(entity=existingEntry)
    else:
        logging.error("[{}]: Error finding checkpoint entry to update".format(logType))

# Track the rate of calls made to the MongoDB Atlas API by Group ID  
def api_rate_limit_tracking(groupId, apiRequestCounter):
    
    requestTime = datetime.now()
    previousMin = requestTime - timedelta(minutes=1)
    
    counterEntry = {}
    for i in apiRequestCounter:
        if i['groupId'] == groupId:
            counterEntry = i
            
    counterEntry['requestTimes'].append(requestTime)

    requestInLastMin = 0
    for i in counterEntry['requestTimes']:
        if i > previousMin:
            requestInLastMin += 1

    if requestInLastMin > 95:
        logging.warning("GroupID={} Nearing API Rate Limit, suspending requests for 10 seconds".format(groupId))
        time.sleep(10)

# Calculates play size in MB   
def calculate_obj_size(payload, output, bsize=1024):
    """
    convert bytes to megabytes, etc.
       sample code:
           print('mb= ' + str(bytesto(314575262000000, 'm')))
       sample output: 
           mb= 300002347.946
    """

    bytes = round(len(payload.encode('utf-8')))
    
    a = {'k' : 1, 'm': 2, 'g' : 3, 't' : 4, 'p' : 5, 'e' : 6 }
    r = float(bytes)
    for i in range(a[output]):
        r = r / bsize
        
    return(r)

# Convert time values to an epoch time value
def convert_to_epoch(time, dateFormat):
    time_dt = datetime.strptime(time, dateFormat)
    epoch = int((time_dt - datetime.utcfromtimestamp(0)).total_seconds())
    return epoch

# Function to split JSON payloads greater than the 30MB Log Analytics API limit into chunks
def payload_split(payload, payloadSize, logType):
    
    increment = payloadSize / 30
    groupOf = math.floor(len(payload) / increment) 
    chunks = [payload[i:i + groupOf] for i in range(0, len(groupOf), groupOf)] 
    logging.warning("[{}]: Payload will be broken up into groupings of {} records".format(logType, groupOf))
    
    return chunks

# Convert the decompressed Host Audit logs to JSON for processing
def convert_to_json(raw):
    """
    Converts the raw bytes version of audit logs, which are lines of individual json objects, and converts it to an array of objects that is json compliant

    :param raw:     Raw representation of audit logs
    :return:        Converted audit logs in form of json object array
    """
    decoded = raw.decode("UTF-8")
    result = []
    for each in decoded.splitlines():
        json_repr = json.loads(each)
        result.append(json_repr)
    return result